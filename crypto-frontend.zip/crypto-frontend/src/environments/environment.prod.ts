export const environment = {
  production: true,
  HyperledgerApi: 'http://34.230.41.83:3000/api/',
  BackendApi: 'http://34.230.41.83:8081/api/v1/',
  socket_io: 'http://34.230.41.83:8081'
};
