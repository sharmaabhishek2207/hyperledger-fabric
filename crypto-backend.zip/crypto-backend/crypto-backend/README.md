# To run backend
node ./bin/www